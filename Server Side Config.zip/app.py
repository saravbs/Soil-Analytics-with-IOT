import flask
from flask import request

app = flask.Flask(__name__)
app.config["DEBUG"] = False

@app.route('/', methods=['POST', 'GET'])
def home():
    print(request.data)
    return ''

app.run(host='0.0.0.0', port=7000)
